import React, { useEffect, useState } from "react";
import type { Errors, Touched, UserInfo } from "../../types/auth.model";
import { Link, useNavigate } from "react-router";
import "./form.css";
import { ClipLoader } from "react-spinners";
import { useAuth } from "../../context/AuthContext";
const Registerform = () => {
  const navigate = useNavigate();
  const [userInfo, setuserInfo] = useState<UserInfo>({
    userName: "",
    email: "",
    password: "",
  });
  const { register } = useAuth();
  const [errors, setErrors] = useState<Errors>({});
  const [touched, setTouched] = useState<Touched>({});
  const [backendErrors, setbackendErrors] = useState("");
  const [isLoading, setisLoading] = useState(false);

  const validateForm = (userInfo: UserInfo): Errors => {
    const errors: Errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;
    if (!userInfo.userName.trim()) {
      errors.userName = "userName is required!";
    } else if (userInfo.userName.length < 3) {
      errors.userName = "min length is 3 character";
    }
    if (!userInfo.email.trim()) {
      errors.email = "email is required!";
    } else if (!emailRegex.test(userInfo.email)) {
      errors.email = "invalid email";
    }
    if (!userInfo.password.trim()) {
      errors.password = "password is required!";
    } else if (!passwordRegex.test(userInfo.password)) {
      errors.password =
        "password must be at least 8 character one letter one number one special character ";
    }
    return errors;
  };
  useEffect(() => {
    setErrors(validateForm(userInfo));
  }, [userInfo]);
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setuserInfo((prev) => ({ ...prev, [name]: value }));
    if (backendErrors) {
      setbackendErrors("");
    }
  };
  const handleBlur = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
  };
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setTouched({ userName: true, email: true, password: true });
    const FormErrors = validateForm(userInfo);
    if (Object.keys(FormErrors).length > 0) {
      setErrors(FormErrors);  
      return;
    }
    setisLoading(true)
    const res = await register(
      userInfo.userName,
      userInfo.email,
      userInfo.password
    );
    setisLoading(false)
  
      if (res.success) {
        navigate("/home");
      } else {
        setbackendErrors(res.error || "register failed duo to network");
      }
    
  };
  return (
    <div className="wrapper">
      <form onSubmit={handleSubmit} method="POST">
        <h1>Signup</h1>
        <div className="input-Box">
          <input
            type="text"
            placeholder="userName"
            name="userName"
            disabled={isLoading}
            value={userInfo.userName}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {touched.userName && errors.userName && (
            <span>
              {" "}
              {errors.userName} {}
            </span>
          )}
        </div>
        <div className="input-Box">
          <input
            disabled={isLoading}
            type="email"
            placeholder="email"
            name="email"
            value={userInfo.email}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {touched.email && errors.email && <span>{errors.email}</span>}
        </div>
        <div className="input-Box">
          <input
            disabled={isLoading}
            type="password"
            placeholder="password"
            name="password"
            value={userInfo.password}
            onChange={handleChange}
            onBlur={handleBlur}
          />
          {touched.password && errors.password && (
            <span> {errors.password} </span>
          )}
          {backendErrors && <span> {backendErrors} </span>}
        </div>
        <div className="submit-Btn">
          <button type="submit" disabled={isLoading}>
            {isLoading ? <ClipLoader size={20} /> : "Signup"}
          </button>
        </div>
        <div className="register-Link">
          <p>
            already have an account ? <Link to="/login">Login</Link>
          </p>
        </div>
      </form>
    </div>
  );
};

export default Registerform;
