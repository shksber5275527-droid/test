import React, { useState } from "react";
import "./form.css";
import { Link, useNavigate } from "react-router";
import type { LoginInfo } from "../../types/auth.model";
import { useAuth } from "../../context/AuthContext";
import { ClipLoader } from "react-spinners";
const Loginform = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [userInfo, setuserInfo] = useState<LoginInfo>({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [isLoading, setisLoading] = useState(false);

  const validateForm = (userInfo: LoginInfo): boolean => {
    if (!userInfo.email.trim()) {
      setError("email is required");
      return false;
    }
    if (!userInfo.password.trim()) {
      setError("password is required");
      return false;
    }
    return true;
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    setuserInfo((prev) => ({ ...prev, [name]: value }));
  };
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validateForm(userInfo)) {
      return;
    }
    setError("");
    setisLoading(true);
    const res = await login(userInfo.email, userInfo.password);
    console.log(res);
    
    setisLoading(false);
    if (res.success) {
      navigate("/home");
    } else {
      setError(res.error || "login failed");
    }
  };

  return (
    <>
      <div className="wrapper">
        <form onSubmit={handleSubmit}>
          <h1>Login</h1>
          <div className="input-Box">
            <input
              disabled={isLoading}
              type="text"
              name="email"
              placeholder="email"
              value={userInfo.email}
              onChange={handleChange}
            />
          </div>
          <div className="input-Box">
            <input
              disabled={isLoading}
              type="password"
              name="password"
              placeholder="password"
              value={userInfo.password}
              onChange={handleChange}
            />
            {error && <span>{error}</span>}
          </div>
          <div className="submit-Btn">
            <button type="submit" disabled={isLoading}>
              {isLoading ? <ClipLoader size={20} /> : "Login"}
            </button>
          </div>
          <div className="register-Link">
            <p>
              Dont have an account ? <Link to="/register">Register</Link>
            </p>
          </div>
        </form>
      </div>
    </>
  );
};

export default Loginform;
